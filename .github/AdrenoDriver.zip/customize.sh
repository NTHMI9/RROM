# info
SOC=`getprop ro.soc.model`
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " "
ui_print " Version=$MODVER"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " "
ui_print " GL/vk v@707.0 Rev2 FINAL 💟"
ui_print " Donation group"
ui_print " https://www.paypal.me/AdrenoGROUP"
ui_print " "
ui_print " - Mount Check..."
sleep 3
ui_print " - Success🥰"
ui_print " "
ui_print " - Android Version Check..."
sleep 3
[ $(getprop ro.system.build.version.sdk) -lt 30 ] && echo "! Unsupported android version detected, please upgrade🥴" && abort
echo " - Success🥰"
echo " "
ui_print " - Processor Check..."
sleep 3
if [ $SOC != "SM8350" ] && [ $SOC != "SM8450" ] && [ $SOC != "SM8475" ] && [ $SOC != "SM8550-AC" ] && [ $SOC != "SM8550-AB" ] && [ $SOC != "SM8350-AC" ];
then
echo " - Success🥰"
echo " "
else
echo " "
echo "! Processor does not support High bootloop risk." && abort
echo " "
fi
ui_print " - Patching driver please Wait...🙂"

sleep 15

# add patch permission
set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/lib* 0 0 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH  0  0  0755  0644
set_perm_recursive $MODPATH/system/vendor/firmware 0 0 0755 0644 u:object_r:vendor_firmware_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/etc/permissions/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0

# add patch permission 32bit
set_perm_recursive $MODPATH/system/vendor/lib/egl/eglSubDriverAndroid.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/libEGL_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/libGLESv1_CM_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/libGLESv2_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/libq3dtools_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/egl/libq3dtools_esx.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/lib/libGLESv1.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/lib/libGLESv2.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/hw/vulkan.adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/notgsl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libadreno_app_profiles.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libadreno_utils.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libbase64.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libllvm-glnext.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libllvm-qgl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/libq3dtools_adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/vendor.qti.hardware.display.mapper@3.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/vendor.qti.hardware.display.mapper@4.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/vendor.qti.hardware.display.mapperextensions@1.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/vendor.qti.hardware.display.mapperextensions@1.1.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0

# add patch permission 64bit
set_perm_recursive $MODPATH/system/vendor/lib64/egl/eglSubDriverAndroid.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/libEGL_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/libGLESv1_CM_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/libGLESv2_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/libq3dtools_adreno.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/egl/libq3dtools_esx.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/lib64/libGLESv1.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/lib64/libGLESv2.so 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/hw/vulkan.adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libc++.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/gpu++.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libadreno_app_profiles.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libadreno_utils.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libgsl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libgsl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/notgsl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libgpudataproducer.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libbase64.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libllvm-glnext.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libllvm-qgl.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libq3dtools_adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libEGL_adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libGLESv2_adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/libcutlis.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapper@1.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapper@2.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapper@3.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapper@4.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapperextensions@1.0.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/vendor.qti.hardware.display.mapperextensions@1.1.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/notllvm-glnext.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/etc/permissions/public.libraries.txt 0 0 0755 0644 u:object_r:same_process_hal_file:s0
chmod 644 /system/vendor/firmware/a650_sqe.fw
chmod 644 /system/vendor/firmware/a650_gmu.bin

ui_print " - Success🥰"

ui_print " "
ui_print " - GPU Cache Cleaner Wait..."
sleep 3
# chace cleaner
CACHE=$(find /data/user_de -name *shaders_cache* -type f | grep code_cache)
for i in $CACHE; do
    rm -rf $i
done
for i in "$(find /data -type f -name '*shader*')"; do
 rm -f $i
done
ui_print " - Success🥰"
sleep 3
ui_print " "
ui_print " - GL/vk v@707.0 Rev2 FINAL 💟. ALL DONE"
ui_print " "
ui_print " ⠀⢠⣶⣿⣿⣗⡢⠀⠀⠀⠀⠀⠀⢤⣒⣿⣿⣷⣆⠀⠀"
ui_print " ⠀⠋⠉⠉⠙⠻⣿⣷⡄⠀⠀⠀⣴⣿⠿⠛⠉⠉⠉⠃⠀"
ui_print " ⠀⠀⢀⡠⢤⣠⣀⡹⡄⠀⠀⠀⡞⣁⣤⣠⠤⡀⠀⠀⠀"
ui_print " ⢐⡤⢾⣿⣿⢿⣿⡿⠀⠀⠀⠀⠸⣿⣿⢿⣿⣾⠦⣌⠀"
ui_print " ⠁⠀⠀⠀⠉⠈⠀⠀⣸⠀⠀⢰⡀⠀⠈⠈⠀⠀⠀⠀⠁"
ui_print " ⠀⠀⠀⠀⠀⠀⣀⡔⢹⠀⠀⢸⠳⡄⡀⠀⠀⠀⠀⠀⠀"
ui_print " ⠸⡦⣤⠤⠒⠋⠘⢠⡸⣀⣀⡸⣠⠘⠉⠓⠠⣤⢤⡞⠀"
ui_print " ⠀⢹⡜⢷⣄⠀⣀⣀⣾⡶⢶⣷⣄⣀⡀⢀⣴⢏⡾⠁⠀"
ui_print " ⠀⠀⠹⡮⡛⠛⠛⠻⠿⠥⠤⠽⠿⠛⠛⠛⡾⠁⠀⠀"
ui_print " ⠀⠀⠀⠙⢄⠁⠀⠀⠀⣄⣀⡄⠀⠀⠀⢁⠞⠀⠀⠀⠀"
ui_print " ⠀⠀⠀⠀⠀⠂⠀⠀⠀⢸⣿⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀"
ui_print " ⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
ui_print " ⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
ui_print " "
ui_print " - Please , Reboot your phone now !!!"